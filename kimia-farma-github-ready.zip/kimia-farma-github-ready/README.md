# Kimia Farma — Business Performance Analytics Dashboard (2020–2023)

Dashboard Business Intelligence untuk mengeksplorasi kinerja penjualan, performa cabang, kontribusi produk, rating transaksi, dan catatan inventaris Kimia Farma periode 2020–2023.

## Demo

Setelah GitHub Pages aktif, URL umumnya:

`https://<username>.github.io/<repository-name>/`

Ganti placeholder dengan username dan nama repository GitHub Anda.

## Fitur

- **Overview:** KPI utama dan ringkasan performa.
- **Sales Analytics:** tren penjualan bulanan/tahunan dan analisis diskon.
- **Regional Analytics:** kontribusi provinsi, cabang, dan rating wilayah.
- **Product Analytics:** kinerja kategori dan produk.
- **Customer Experience:** distribusi rating transaksi.
- **Inventory Analysis:** jumlah catatan, pasangan cabang-produk unik, catatan bernilai nol, dan distribusi opname.
- Filter global tahun, provinsi, kategori cabang, dan kategori produk.
- Ekspor ringkasan sesuai filter aktif.

## Teknologi

- HTML5
- CSS3 dan Tailwind CSS CDN
- Vanilla JavaScript
- Chart.js
- PapaParse
- GitHub Pages untuk hosting statis

## Struktur repository

```text
.
├── index.html
├── script.js
├── style.css
├── README.md
├── .nojekyll
└── data/
    └── raw/
        ├── kf_final_transaction.csv
        ├── kf_inventory.csv
        ├── kf_kantor_cabang.csv
        └── kf_product.csv
```

## Dataset untuk versi publik

Versi publik ini mempertahankan seluruh baris data, tetapi hanya menyertakan kolom yang dibutuhkan oleh dashboard. Kolom yang tidak digunakan dihilangkan untuk mengurangi ukuran file:

| File | Kolom yang disertakan |
|---|---|
| `kf_final_transaction.csv` | `date`, `branch_id`, `product_id`, `price`, `discount_percentage`, `rating` |
| `kf_inventory.csv` | `branch_id`, `product_id`, `opname_stock` |
| `kf_kantor_cabang.csv` | `branch_id`, `branch_category`, `branch_name`, `kota`, `provinsi`, `rating` |
| `kf_product.csv` | `product_id`, `product_name`, `product_category`, `price` |

`transaction_id` dan `customer_name` tidak disertakan pada file transaksi publik karena tidak diperlukan untuk visualisasi dashboard. Setiap baris transaksi tetap dipertahankan. `Inventory_ID` dan `product_name` dari tabel inventaris juga tidak disertakan karena tidak digunakan; referensi nama produk berasal dari tabel produk.

File CSV asli pengguna tidak diubah. File di `data/raw/` dalam repository ini adalah salinan publik yang dipangkas kolomnya, bukan data yang diagregasi atau disampling.

## Cara menjalankan secara lokal

1. Unduh atau clone repository.
2. Pastikan folder `data/raw/` dan empat CSV ada di lokasi tersebut.
3. Buka folder proyek di IBM Bob atau Visual Studio Code.
4. Jalankan `index.html` menggunakan Live Server.
5. Pastikan koneksi internet tersedia untuk memuat library CDN.

Jangan membuka `index.html` langsung dengan skema `file://`; gunakan local development server agar browser dapat mengambil CSV melalui HTTP.

## Cara mengaktifkan GitHub Pages

1. Buat repository GitHub.
2. Unggah seluruh isi folder proyek ke root repository.
3. Buka **Settings → Pages**.
4. Pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu simpan.
6. Setelah deployment berhasil, buka URL yang disediakan GitHub Pages.

## Definisi KPI

- **Net Sales:** `SUM(price × (1 − discount_percentage))`.
- **Total Transactions:** jumlah baris transaksi valid; dataset ini menggunakan satu baris per transaksi.
- **Average Transaction Value:** Net Sales dibagi Total Transactions.
- **Average Discount:** rata-rata `discount_percentage` dikalikan 100%.
- **Average Transaction Rating:** rata-rata nilai `rating` yang tersedia.
- **Branches Transacting:** jumlah `branch_id` unik yang memiliki transaksi pada filter aktif.

## Catatan metodologi dan batasan

- Dataset transaksi tidak menyediakan quantity; dashboard tidak menghitung unit terjual.
- Dataset tidak menyediakan harga pokok penjualan (HPP); dashboard tidak menghitung laba bersih atau margin laba.
- Dataset inventaris memiliki catatan berulang untuk kombinasi cabang-produk dan tidak menyediakan tanggal pencatatan. Karena itu, `opname_stock` tidak dijumlahkan sebagai stok aktual dan tidak digunakan untuk menentukan status stok kritis.
- Data inventaris tidak memiliki dimensi waktu; filter tahun tidak diterapkan pada analisis inventaris.
- Hasil analisis mencerminkan isi dataset yang disediakan dan bukan laporan resmi atau sistem operasional real-time Kimia Farma.

## Pernyataan penggunaan

Proyek ini dibuat untuk tujuan edukasi dan portofolio analisis data. Proyek ini tidak berafiliasi dengan, tidak didukung oleh, dan bukan merupakan produk resmi Kimia Farma. Pastikan Anda memiliki hak dan izin yang diperlukan sebelum memublikasikan dataset atau turunannya.
